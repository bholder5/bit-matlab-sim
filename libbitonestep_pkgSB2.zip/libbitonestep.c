/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: libbitonestep.c
 *
 * MATLAB Coder version            : 5.6
 * C/C++ source code generated on  : 23-Sep-2024 05:53:32
 */

/* Include Files */
#include "libbitonestep.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>
#include <string.h>

/* Function Declarations */
static void axis2rot(const double v[3], double phi, double rot[9]);

static void bit_one_step_anonFcn1(const double c_n[27], const double z_n[27],
                                  const double m_n[9], const double r_n1_n[27],
                                  const double m_w_n[324], const double p_n[54],
                                  const double k_d[9], const double b_d[9],
                                  const double g0[3], const double unlock[9],
                                  const double hs_rw_max[3], double w_piv,
                                  unsigned char piv_flag, double tau_max_piv,
                                  double thet_pit_nom, const double y_true[21],
                                  const double tau_applied[9], double dw_piv,
                                  double varargout_1[24]);

static int div_nde_s32_floor(int numerator);

static void mldivide(const double A[81], double B[9]);

/* Function Definitions */
/*
 * This function gives the rotation matric applied to other rotation
 *  matricies, not the vector (it is transpose of the rot mat applied to the
 *  vector.
 *
 * Arguments    : const double v[3]
 *                double phi
 *                double rot[9]
 * Return Type  : void
 */
static void axis2rot(const double v[3], double phi, double rot[9])
{
  double b_sign;
  double cosa;
  double sina;
  int j;
  int k;
  cosa = cos(phi);
  sina = sin(phi);
  b_sign = 1.0;
  memset(&rot[0], 0, 9U * sizeof(double));
  for (k = 0; k < 3; k++) {
    int i;
    i = 2 - k;
    for (j = 0; j <= i; j++) {
      double mij;
      int b_j;
      b_j = k + j;
      mij = (1.0 - cosa) * v[k] * v[b_j];
      if (k == b_j) {
        rot[k + 3 * b_j] = mij + cosa;
      } else {
        double rot_tmp;
        /* index is 3 - j - k for 0 indexed programming languages */
        rot_tmp = b_sign * sina * v[3 - (k + b_j)];
        rot[k + 3 * b_j] = mij + rot_tmp;
        rot[b_j + 3 * k] = mij - rot_tmp;
        b_sign = -b_sign;
      }
    }
  }
}

/*
 * Arguments    : const double c_n[27]
 *                const double z_n[27]
 *                const double m_n[9]
 *                const double r_n1_n[27]
 *                const double m_w_n[324]
 *                const double p_n[54]
 *                const double k_d[9]
 *                const double b_d[9]
 *                const double g0[3]
 *                const double unlock[9]
 *                const double hs_rw_max[3]
 *                double w_piv
 *                unsigned char piv_flag
 *                double tau_max_piv
 *                double thet_pit_nom
 *                const double y_true[21]
 *                const double tau_applied[9]
 *                double dw_piv
 *                double varargout_1[24]
 * Return Type  : void
 */
static void bit_one_step_anonFcn1(const double c_n[27], const double z_n[27],
                                  const double m_n[9], const double r_n1_n[27],
                                  const double m_w_n[324], const double p_n[54],
                                  const double k_d[9], const double b_d[9],
                                  const double g0[3], const double unlock[9],
                                  const double hs_rw_max[3], double w_piv,
                                  unsigned char piv_flag, double tau_max_piv,
                                  double thet_pit_nom, const double y_true[21],
                                  const double tau_applied[9], double dw_piv,
                                  double varargout_1[24])
{
  double T_n[324];
  double C_n[81];
  double C_n_rate[81];
  double c_r_tmp[81];
  double T_nj[36];
  double b_T_n[36];
  double b_T_ni[36];
  double b_dVdtheta_i[27];
  double b_r_tmp[27];
  double r_tmp[27];
  double s7[27];
  double Pot[9];
  double b_C_n[9];
  double b_tau_applied[9];
  double dC_10[9];
  double dVdtheta_i[9];
  double dtheta[9];
  double t1[9];
  double c_C_n[3];
  double d;
  double d1;
  double d_hs_idx_0;
  double d_hs_idx_1;
  double d_hs_idx_2;
  double m_i;
  double ssq;
  double tau_piv;
  int T_n_tmp;
  int b_T_n_tmp;
  int b_i;
  int b_j;
  int i;
  int i1;
  int i2;
  int idxA1j;
  int idxAjj;
  int idxAjjp1;
  int j;
  int jmax;
  int k;
  int n;
  boolean_T x[3];
  boolean_T exitg1;
  boolean_T y;
  /* split the state */
  memcpy(&b_tau_applied[0], &tau_applied[0], 9U * sizeof(double));
  memcpy(&dtheta[0], &y_true[0], 9U * sizeof(double));
  /* extract RW torque. */
  b_tau_applied[6] = 0.0;
  /*  set pivot speed in dtheta... */
  if (piv_flag == 1) {
    dtheta[5] = w_piv;
  }
  /*     %% */
  /*  This function is implementing the potential energy term of the */
  /*  lagrangian. See section 3.1.1 of Romualdez Thesis, specifically */
  /*  Eq3.25-3.26. The rate is because of the partial derivitive of V wrt */
  /*  theta.  */
  /* Determine relative rotation matrices and rates for each joint */
  /* rotation matricies */
  /*  Potential energy */
  b_C_n[0] = -0.0;
  b_C_n[4] = -0.0;
  b_C_n[8] = -0.0;
  for (n = 0; n < 9; n++) {
    Pot[n] = 0.0;
    axis2rot(&z_n[3 * n], y_true[n + 9], *(double(*)[9]) & C_n[9 * n]);
    /* Partial of Rot_n with respect to theta_n */
    m_i = z_n[3 * n + 2];
    b_C_n[3] = m_i;
    ssq = z_n[3 * n + 1];
    b_C_n[6] = -ssq;
    b_C_n[1] = -m_i;
    m_i = z_n[3 * n];
    b_C_n[7] = m_i;
    b_C_n[2] = ssq;
    b_C_n[5] = -m_i;
    for (i = 0; i < 3; i++) {
      d = b_C_n[i];
      d1 = b_C_n[i + 3];
      tau_piv = b_C_n[i + 6];
      for (i1 = 0; i1 < 3; i1++) {
        T_n_tmp = 3 * i1 + 9 * n;
        C_n_rate[(i + 3 * i1) + 9 * n] =
            (d * C_n[T_n_tmp] + d1 * C_n[T_n_tmp + 1]) +
            tau_piv * C_n[T_n_tmp + 2];
      }
    }
  }
  /*  Compute potential energy term. First loop is cycling through each */
  /*  koints contribution. */
  for (n = 0; n < 9; n++) {
    m_i = 0.0;
    memset(&dVdtheta_i[0], 0, 9U * sizeof(double));
    /*  mass of remaining link (ex. 7 + 8 + 9) is totla mass at OF joint */
    i = 8 - n;
    for (jmax = 0; jmax <= i; jmax++) {
      m_i += m_n[n + jmax];
    }
    if (m_i != 0.0) {
      memset(&t1[0], 0, 9U * sizeof(double));
      /* Cycling through all joints up to joint n, the jint we are */
      /* currently calculating the contribution from */
      /*  */
      /* terms up to n-1 links.  */
      for (j = 0; j < n; j++) {
        memset(&dC_10[0], 0, 9U * sizeof(double));
        dC_10[0] = 1.0;
        dC_10[4] = 1.0;
        dC_10[8] = 1.0;
        for (k = 0; k < n; k++) {
          /* This multiplies the rotation matricies successively */
          /*  until the link j where the rate is inserted instead */
          if (k == j) {
            for (i = 0; i < 3; i++) {
              i1 = i + 9 * k;
              for (T_n_tmp = 0; T_n_tmp < 3; T_n_tmp++) {
                b_C_n[i + 3 * T_n_tmp] =
                    (C_n_rate[i1] * dC_10[3 * T_n_tmp] +
                     C_n_rate[i1 + 3] * dC_10[3 * T_n_tmp + 1]) +
                    C_n_rate[i1 + 6] * dC_10[3 * T_n_tmp + 2];
              }
            }
            memcpy(&dC_10[0], &b_C_n[0], 9U * sizeof(double));
          } else {
            for (i = 0; i < 3; i++) {
              i1 = i + 9 * k;
              for (T_n_tmp = 0; T_n_tmp < 3; T_n_tmp++) {
                b_C_n[i + 3 * T_n_tmp] =
                    (C_n[i1] * dC_10[3 * T_n_tmp] +
                     C_n[i1 + 3] * dC_10[3 * T_n_tmp + 1]) +
                    C_n[i1 + 6] * dC_10[3 * T_n_tmp + 2];
              }
            }
            memcpy(&dC_10[0], &b_C_n[0], 9U * sizeof(double));
          }
        }
        ssq = 0.0;
        d = r_n1_n[3 * n];
        d1 = r_n1_n[3 * n + 1];
        tau_piv = r_n1_n[3 * n + 2];
        for (i = 0; i < 3; i++) {
          ssq += ((d * dC_10[3 * i] + d1 * dC_10[3 * i + 1]) +
                  tau_piv * dC_10[3 * i + 2]) *
                 g0[i];
        }
        t1[j] = ssq;
      }
      /* %% PE terms that go from 1:n */
      d = c_n[3 * n];
      d1 = c_n[3 * n + 1];
      tau_piv = c_n[3 * n + 2];
      for (j = 0; j <= n; j++) {
        memset(&dC_10[0], 0, 9U * sizeof(double));
        dC_10[0] = 1.0;
        dC_10[4] = 1.0;
        dC_10[8] = 1.0;
        for (k = 0; k <= n; k++) {
          /* This multiplies the rotation matricies successively */
          /*  until the link j is reached in which case the rate */
          /*  is multiplied by the overall rotation */
          if (k == j) {
            for (i = 0; i < 3; i++) {
              i1 = i + 9 * k;
              for (T_n_tmp = 0; T_n_tmp < 3; T_n_tmp++) {
                b_C_n[i + 3 * T_n_tmp] =
                    (C_n_rate[i1] * dC_10[3 * T_n_tmp] +
                     C_n_rate[i1 + 3] * dC_10[3 * T_n_tmp + 1]) +
                    C_n_rate[i1 + 6] * dC_10[3 * T_n_tmp + 2];
              }
            }
            memcpy(&dC_10[0], &b_C_n[0], 9U * sizeof(double));
          } else {
            for (i = 0; i < 3; i++) {
              i1 = i + 9 * k;
              for (T_n_tmp = 0; T_n_tmp < 3; T_n_tmp++) {
                b_C_n[i + 3 * T_n_tmp] =
                    (C_n[i1] * dC_10[3 * T_n_tmp] +
                     C_n[i1 + 3] * dC_10[3 * T_n_tmp + 1]) +
                    C_n[i1 + 6] * dC_10[3 * T_n_tmp + 2];
              }
            }
            memcpy(&dC_10[0], &b_C_n[0], 9U * sizeof(double));
          }
        }
        /* dot product */
        /* %%% made change here c_n(n) -> c_n(:,n) */
        ssq = 0.0;
        for (i = 0; i < 3; i++) {
          ssq += ((d * dC_10[3 * i] + d1 * dC_10[3 * i + 1]) +
                  tau_piv * dC_10[3 * i + 2]) *
                 g0[i];
        }
        dVdtheta_i[j] = -m_i * t1[j] - ssq;
      }
    }
    for (i = 0; i < 9; i++) {
      Pot[i] += dVdtheta_i[i];
    }
  }
  memcpy(&t1[0], &y_true[9], 9U * sizeof(double));
  t1[8] = y_true[17] - thet_pit_nom;
  /* place holder */
  /* UNTITLED Summary of this function goes here */
  /*    Detailed explanation goes here */
  /* calculate the mapping matrix from dtheta to omega */
  memset(&s7[0], 0, 27U * sizeof(double));
  for (b_i = 0; b_i < 7; b_i++) {
    axis2rot(&z_n[3 * b_i], y_true[b_i + 9], dVdtheta_i);
    s7[3 * b_i] = z_n[3 * b_i];
    jmax = 3 * b_i + 1;
    s7[jmax] = z_n[jmax];
    jmax = 3 * b_i + 2;
    s7[jmax] = z_n[jmax];
    for (i = 0; i < 3; i++) {
      d = dVdtheta_i[i];
      d1 = dVdtheta_i[i + 3];
      tau_piv = dVdtheta_i[i + 6];
      for (i1 = 0; i1 < 9; i1++) {
        b_dVdtheta_i[i + 3 * i1] =
            (d * s7[3 * i1] + d1 * s7[3 * i1 + 1]) + tau_piv * s7[3 * i1 + 2];
      }
    }
    memcpy(&s7[0], &b_dVdtheta_i[0], 27U * sizeof(double));
  }
  d_hs_idx_0 = tau_applied[6] * z_n[18];
  x[0] = (y_true[20] >= hs_rw_max[0]);
  d_hs_idx_1 = tau_applied[6] * z_n[19];
  x[1] = (y_true[20] >= hs_rw_max[1]);
  d_hs_idx_2 = tau_applied[6] * z_n[20];
  x[2] = (y_true[20] >= hs_rw_max[2]);
  y = true;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 3)) {
    if (!x[k]) {
      y = false;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (d_hs_idx_2 > 0.0) {
      d_hs_idx_2 = 0.0;
    }
  } else {
    x[0] = (y_true[20] <= -hs_rw_max[0]);
    x[1] = (y_true[20] <= -hs_rw_max[1]);
    x[2] = (y_true[20] <= -hs_rw_max[2]);
    y = true;
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k < 3)) {
      if (!x[k]) {
        y = false;
        exitg1 = true;
      } else {
        k++;
      }
    }
    if (y && (d_hs_idx_2 < 0.0)) {
      d_hs_idx_2 = 0.0;
    }
  }
  for (i = 0; i < 3; i++) {
    for (i1 = 0; i1 < 9; i1++) {
      b_dVdtheta_i[i1 + 9 * i] = s7[i + 3 * i1];
    }
  }
  /*  rw_g2 = 2.353962297635081; */
  /*  rw_g1 = 0.034; */
  /*  w_piv = rw_g1*((-hs(3)/i_rw(3,3))-w_rw_nom) - (rw_g2*tau_rw); */
  /* calculate joint torques from gravity elasticity and damnping according */
  /* to eq 3.37 */
  for (i = 0; i < 27; i++) {
    r_tmp[i] = -b_dVdtheta_i[i];
  }
  b_C_n[0] = 0.0;
  b_C_n[3] = -y_true[20];
  b_C_n[6] = y_true[19];
  b_C_n[1] = y_true[20];
  b_C_n[4] = 0.0;
  b_C_n[7] = -y_true[18];
  b_C_n[2] = -y_true[19];
  b_C_n[5] = y_true[18];
  b_C_n[8] = 0.0;
  for (i = 0; i < 9; i++) {
    d = r_tmp[i];
    d1 = r_tmp[i + 9];
    tau_piv = r_tmp[i + 18];
    for (i1 = 0; i1 < 3; i1++) {
      b_r_tmp[i + 9 * i1] = (d * b_C_n[3 * i1] + d1 * b_C_n[3 * i1 + 1]) +
                            tau_piv * b_C_n[3 * i1 + 2];
    }
    d = 0.0;
    d1 = b_r_tmp[i];
    tau_piv = b_r_tmp[i + 9];
    m_i = b_r_tmp[i + 18];
    for (i1 = 0; i1 < 9; i1++) {
      d += ((d1 * s7[3 * i1] + tau_piv * s7[3 * i1 + 1]) +
            m_i * s7[3 * i1 + 2]) *
           dtheta[i1];
    }
    d = b_tau_applied[i] -
        ((((Pot[i] + k_d[i] * t1[i]) + b_d[i] * dtheta[i]) + d) +
         ((b_dVdtheta_i[i] * d_hs_idx_0 + b_dVdtheta_i[i + 9] * d_hs_idx_1) +
          b_dVdtheta_i[i + 18] * d_hs_idx_2));
    b_tau_applied[i] = d;
    dC_10[i] = d;
  }
  /* Compute_Mass_Matrix computes the mass matrix of the 9 state system using */
  /* the angles theta to calculate the interbody transformation matrices and */
  /* the axis of rotations. */
  /*  Initialize mass matrix */
  memset(&C_n[0], 0, 81U * sizeof(double));
  /*  memory to store the interbody transformations */
  /*  equation 3.8: Interbody transformations for each frame */
  b_C_n[0] = 0.0;
  b_C_n[4] = 0.0;
  b_C_n[8] = 0.0;
  for (b_i = 0; b_i < 9; b_i++) {
    axis2rot(&z_n[3 * b_i], y_true[b_i + 9], dVdtheta_i);
    d = r_n1_n[3 * b_i + 2];
    b_C_n[3] = -d;
    d1 = r_n1_n[3 * b_i + 1];
    b_C_n[6] = d1;
    b_C_n[1] = d;
    d = r_n1_n[3 * b_i];
    b_C_n[7] = -d;
    b_C_n[2] = -d1;
    b_C_n[5] = d;
    for (i = 0; i < 3; i++) {
      for (i1 = 0; i1 < 3; i1++) {
        b_tau_applied[i + 3 * i1] = (-dVdtheta_i[i] * b_C_n[3 * i1] +
                                     -dVdtheta_i[i + 3] * b_C_n[3 * i1 + 1]) +
                                    -dVdtheta_i[i + 6] * b_C_n[3 * i1 + 2];
        T_n[(i1 + 6 * i) + 36 * b_i] = dVdtheta_i[i1 + 3 * i];
      }
    }
    for (i = 0; i < 3; i++) {
      jmax = 6 * (i + 3) + 36 * b_i;
      T_n[jmax] = b_tau_applied[3 * i];
      b_T_n_tmp = 6 * i + 36 * b_i;
      T_n[b_T_n_tmp + 3] = 0.0;
      T_n[jmax + 3] = dVdtheta_i[3 * i];
      T_n_tmp = 3 * i + 1;
      T_n[jmax + 1] = b_tau_applied[T_n_tmp];
      T_n[b_T_n_tmp + 4] = 0.0;
      T_n[jmax + 4] = dVdtheta_i[T_n_tmp];
      T_n_tmp = 3 * i + 2;
      T_n[jmax + 2] = b_tau_applied[T_n_tmp];
      T_n[b_T_n_tmp + 5] = 0.0;
      T_n[jmax + 5] = dVdtheta_i[T_n_tmp];
    }
  }
  /*  Generate the mass matrix */
  /*  Eq 3.12-3.13 */
  for (b_i = 0; b_i < 9; b_i++) {
    i = 8 - b_i;
    for (j = 0; j <= i; j++) {
      b_j = b_i + j;
      m_i = 0.0;
      i1 = 8 - b_j;
      if (i1 >= 0) {
        i2 = b_j - b_i;
      }
      for (n = 0; n <= i1; n++) {
        double T_ni[6];
        idxA1j = b_j + n;
        memset(&b_T_ni[0], 0, 36U * sizeof(double));
        for (k = 0; k < 6; k++) {
          b_T_ni[k + 6 * k] = 1.0;
        }
        memcpy(&T_nj[0], &b_T_ni[0], 36U * sizeof(double));
        for (k = 0; k < i2; k++) {
          /*                  tic */
          jmax = b_i + k;
          for (T_n_tmp = 0; T_n_tmp < 6; T_n_tmp++) {
            for (idxAjj = 0; idxAjj < 6; idxAjj++) {
              d = 0.0;
              for (idxAjjp1 = 0; idxAjjp1 < 6; idxAjjp1++) {
                d += T_n[(T_n_tmp + 6 * idxAjjp1) + 36 * (jmax + 1)] *
                     b_T_ni[idxAjjp1 + 6 * idxAjj];
              }
              b_T_n[T_n_tmp + 6 * idxAjj] = d;
            }
          }
          memcpy(&b_T_ni[0], &b_T_n[0], 36U * sizeof(double));
          /*                  toc */
          /*                  tic */
          /*                  T_ni = mtimes(T_n(:,:,k),T_ni); */
          /*                  toc */
        }
        T_n_tmp = idxA1j - b_j;
        for (k = 0; k < T_n_tmp; k++) {
          jmax = b_j + k;
          for (idxAjj = 0; idxAjj < 6; idxAjj++) {
            for (idxAjjp1 = 0; idxAjjp1 < 6; idxAjjp1++) {
              d = 0.0;
              for (b_T_n_tmp = 0; b_T_n_tmp < 6; b_T_n_tmp++) {
                d += T_n[(idxAjj + 6 * b_T_n_tmp) + 36 * (jmax + 1)] *
                     T_nj[b_T_n_tmp + 6 * idxAjjp1];
              }
              b_T_n[idxAjj + 6 * idxAjjp1] = d;
            }
          }
          memcpy(&T_nj[0], &b_T_n[0], 36U * sizeof(double));
          /*                  T_nj = mtimes(T_n(:,:,k),T_nj); */
        }
        for (T_n_tmp = 0; T_n_tmp < 6; T_n_tmp++) {
          for (idxAjj = 0; idxAjj < 6; idxAjj++) {
            d = 0.0;
            for (idxAjjp1 = 0; idxAjjp1 < 6; idxAjjp1++) {
              d += T_nj[T_n_tmp + 6 * idxAjjp1] * b_T_ni[idxAjjp1 + 6 * idxAjj];
            }
            b_T_n[T_n_tmp + 6 * idxAjj] = d;
          }
        }
        memcpy(&b_T_ni[0], &b_T_n[0], 36U * sizeof(double));
        /*              T_ni = mtimes(T_nj,T_ni); */
        for (T_n_tmp = 0; T_n_tmp < 6; T_n_tmp++) {
          d = 0.0;
          for (idxAjj = 0; idxAjj < 6; idxAjj++) {
            d += b_T_ni[T_n_tmp + 6 * idxAjj] * p_n[idxAjj + 6 * b_i];
          }
          T_ni[T_n_tmp] = d;
        }
        ssq = 0.0;
        for (T_n_tmp = 0; T_n_tmp < 6; T_n_tmp++) {
          d = 0.0;
          d1 = 0.0;
          for (idxAjj = 0; idxAjj < 6; idxAjj++) {
            d += T_ni[idxAjj] * m_w_n[(idxAjj + 6 * T_n_tmp) + 36 * idxA1j];
            d1 += T_nj[T_n_tmp + 6 * idxAjj] * p_n[idxAjj + 6 * b_j];
          }
          ssq += d * d1;
        }
        m_i += ssq;
      }
      C_n[b_i + 9 * b_j] = m_i;
      if (b_i != b_j) {
        C_n[b_j + 9 * b_i] = m_i;
      }
    }
  }
  /*  M = mass_mat_func(theta); */
  /*  M = mass_mat_func_gb(theta); */
  memcpy(&C_n_rate[0], &C_n[0], 81U * sizeof(double));
  b_j = -2;
  j = 0;
  exitg1 = false;
  while ((!exitg1) && (j < 9)) {
    idxA1j = j * 9;
    idxAjj = idxA1j + j;
    ssq = 0.0;
    if (j >= 1) {
      for (k = 0; k < j; k++) {
        m_i = C_n_rate[idxA1j + k];
        ssq += m_i * m_i;
      }
    }
    m_i = C_n_rate[idxAjj] - ssq;
    if (m_i > 0.0) {
      m_i = sqrt(m_i);
      C_n_rate[idxAjj] = m_i;
      if (j + 1 < 9) {
        b_T_n_tmp = idxA1j + 10;
        idxAjjp1 = idxAjj + 10;
        if (j != 0) {
          i = (idxA1j + 9 * (7 - j)) + 10;
          for (T_n_tmp = b_T_n_tmp; T_n_tmp <= i; T_n_tmp += 9) {
            ssq = 0.0;
            i1 = (T_n_tmp + j) - 1;
            for (jmax = T_n_tmp; jmax <= i1; jmax++) {
              ssq += C_n_rate[jmax - 1] * C_n_rate[(idxA1j + jmax) - T_n_tmp];
            }
            jmax =
                (idxAjj + div_nde_s32_floor((T_n_tmp - idxA1j) - 10) * 9) + 9;
            C_n_rate[jmax] -= ssq;
          }
        }
        m_i = 1.0 / m_i;
        i = (idxAjj + 9 * (7 - j)) + 10;
        for (k = idxAjjp1; k <= i; k += 9) {
          C_n_rate[k - 1] *= m_i;
        }
      }
      j++;
    } else {
      C_n_rate[idxAjj] = m_i;
      b_j = j - 1;
      exitg1 = true;
    }
  }
  if (b_j + 2 == 0) {
    jmax = 7;
  } else {
    jmax = b_j - 1;
  }
  for (j = 0; j <= jmax; j++) {
    i = j + 2;
    if (i <= jmax + 2) {
      memset(&C_n_rate[(j * 9 + i) + -1], 0,
             (unsigned int)((jmax - i) + 3) * sizeof(double));
    }
  }
  for (i = 0; i < 9; i++) {
    for (i1 = 0; i1 < 9; i1++) {
      c_r_tmp[i1 + 9 * i] = C_n_rate[i + 9 * i1];
    }
    dVdtheta_i[i] = dC_10[i];
  }
  mldivide(c_r_tmp, dVdtheta_i);
  mldivide(C_n_rate, dVdtheta_i);
  for (i = 0; i < 9; i++) {
    dVdtheta_i[i] *= unlock[i];
  }
  if (piv_flag == 1) {
    m_i = dw_piv - dVdtheta_i[5];
    ssq = m_i;
    tau_piv = dC_10[5];
    exitg1 = false;
    while ((!exitg1) && (fabs(m_i) > 1.0E-9)) {
      tau_piv += m_i + 0.5 * ssq;
      if (fabs(tau_piv) > tau_max_piv) {
        if (rtIsNaN(tau_piv)) {
          d = rtNaN;
        } else if (tau_piv < 0.0) {
          d = -1.0;
        } else {
          d = (tau_piv > 0.0);
        }
        dC_10[5] = d * tau_max_piv;
        mldivide(c_r_tmp, dC_10);
        memcpy(&dVdtheta_i[0], &dC_10[0], 9U * sizeof(double));
        mldivide(C_n_rate, dVdtheta_i);
        exitg1 = true;
      } else {
        dC_10[5] = tau_piv;
        memcpy(&dVdtheta_i[0], &dC_10[0], 9U * sizeof(double));
        mldivide(c_r_tmp, dVdtheta_i);
        mldivide(C_n_rate, dVdtheta_i);
        m_i = dw_piv - dVdtheta_i[5];
        ssq += m_i;
      }
    }
  }
  /*  tau_gond(1) = tau_rw */
  d = dVdtheta_i[6];
  d1 = dVdtheta_i[7];
  tau_piv = dVdtheta_i[8];
  for (i = 0; i < 3; i++) {
    c_C_n[i] = (C_n[i + 60] * d + C_n[i + 69] * d1) + C_n[i + 78] * tau_piv;
  }
  for (i = 0; i < 9; i++) {
    varargout_1[i] = dVdtheta_i[i];
    varargout_1[i + 9] = dtheta[i];
  }
  varargout_1[18] = d_hs_idx_0;
  varargout_1[21] = c_C_n[0];
  varargout_1[19] = d_hs_idx_1;
  varargout_1[22] = c_C_n[1];
  varargout_1[20] = d_hs_idx_2;
  varargout_1[23] = c_C_n[2];
}

/*
 * Arguments    : int numerator
 * Return Type  : int
 */
static int div_nde_s32_floor(int numerator)
{
  int i;
  if ((numerator < 0) && (numerator % 9 != 0)) {
    i = -1;
  } else {
    i = 0;
  }
  return numerator / 9 + i;
}

/*
 * Arguments    : const double A[81]
 *                double B[9]
 * Return Type  : void
 */
static void mldivide(const double A[81], double B[9])
{
  double b_A[81];
  double smax;
  int A_tmp;
  int a;
  int i;
  int j;
  int jA;
  int jp1j;
  int k;
  signed char ipiv[9];
  memcpy(&b_A[0], &A[0], 81U * sizeof(double));
  for (i = 0; i < 9; i++) {
    ipiv[i] = (signed char)(i + 1);
  }
  for (j = 0; j < 8; j++) {
    int b_tmp;
    int mmj_tmp;
    signed char i1;
    mmj_tmp = 7 - j;
    b_tmp = j * 10;
    jp1j = b_tmp + 2;
    jA = 9 - j;
    a = 0;
    smax = fabs(b_A[b_tmp]);
    for (k = 2; k <= jA; k++) {
      double s;
      s = fabs(b_A[(b_tmp + k) - 1]);
      if (s > smax) {
        a = k - 1;
        smax = s;
      }
    }
    if (b_A[b_tmp + a] != 0.0) {
      if (a != 0) {
        jA = j + a;
        ipiv[j] = (signed char)(jA + 1);
        for (k = 0; k < 9; k++) {
          a = j + k * 9;
          smax = b_A[a];
          A_tmp = jA + k * 9;
          b_A[a] = b_A[A_tmp];
          b_A[A_tmp] = smax;
        }
      }
      i = (b_tmp - j) + 9;
      for (a = jp1j; a <= i; a++) {
        b_A[a - 1] /= b_A[b_tmp];
      }
    }
    jA = b_tmp;
    for (A_tmp = 0; A_tmp <= mmj_tmp; A_tmp++) {
      smax = b_A[(b_tmp + A_tmp * 9) + 9];
      if (smax != 0.0) {
        i = jA + 11;
        a = (jA - j) + 18;
        for (jp1j = i; jp1j <= a; jp1j++) {
          b_A[jp1j - 1] += b_A[((b_tmp + jp1j) - jA) - 10] * -smax;
        }
      }
      jA += 9;
    }
    i1 = ipiv[j];
    if (i1 != j + 1) {
      smax = B[j];
      B[j] = B[i1 - 1];
      B[i1 - 1] = smax;
    }
  }
  for (k = 0; k < 9; k++) {
    jA = 9 * k;
    if (B[k] != 0.0) {
      i = k + 2;
      for (a = i; a < 10; a++) {
        B[a - 1] -= B[k] * b_A[(a + jA) - 1];
      }
    }
  }
  for (k = 8; k >= 0; k--) {
    jA = 9 * k;
    smax = B[k];
    if (smax != 0.0) {
      smax /= b_A[k + jA];
      B[k] = smax;
      for (a = 0; a < k; a++) {
        B[a] -= B[k] * b_A[a + jA];
      }
    }
  }
}

/*
 * Run initialization script
 *
 * Arguments    : const double x0[21]
 *                double tau_applied[9]
 *                const double unlock[9]
 *                double w_piv
 *                unsigned char piv_flag
 *                double dt
 *                unsigned short num_steps
 *                double tau_max_piv
 *                double thet_pit_nom
 *                const double x_flex0[104]
 *                const double tau_flex[5]
 *                unsigned char flexure_flag
 *                unsigned char sb_flag
 *                double y_true[21]
 *                double y_flex[104]
 * Return Type  : void
 */
void bit_one_step(const double x0[21], double tau_applied[9],
                  const double unlock[9], double w_piv, unsigned char piv_flag,
                  double dt, unsigned short num_steps, double tau_max_piv,
                  double thet_pit_nom, const double x_flex0[104],
                  const double tau_flex[5], unsigned char flexure_flag,
                  unsigned char sb_flag, double y_true[21], double y_flex[104])
{
  static const double a_df[10816] = {0.0, -6850.0880077557886,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.1655305169176462,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -7962.6706577762307,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.178467595465129,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -12647.866496740349,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.22492546762641491,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -13102.13472955605,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.22892911330414967,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -17096.533871483229,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.2615074291218758,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -19067.27580068196,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.27616861371764873,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -25085.498408823711,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.31676804389852031,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -26771.233428688109,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.32723834389440443,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -28195.442436642312,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.33582997148344168,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -34562.538682549493,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.37182005692296638,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -36233.2578458545,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.380700711036134,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -48525.3521198063,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.44056941391706389,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -52667.483029779527,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.45898794332653031,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -64059.558804126144,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.5061997977246776,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -64572.011562112908,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.50822047011946658,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -68941.640846773153,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.525134804966394,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -76967.907407482664,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.55486181129172218,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -81003.609059009119,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.56922265962981167,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -90222.62662533854,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.60074163040474737,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -92586.065715088145,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.60855916956394029,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -95916.09088249068,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.619406460678255,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -101665.5083955781,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.6377005830186393,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -108912.3115872177,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.66003730678566264,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -129428.24167601109,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.7195227353628546,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -152960.2015770768,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.78220253535021678,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -154039.89905106369,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.7849583404259457,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -163213.47678699941,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.80799375439912768,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -166657.26090653459,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.816473541289697,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -172526.03224322811,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.83072506220344178,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -176768.18600326759,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.8408761763857211,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -182183.82551471441,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.85365994521170874,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -211920.51399000589,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.92069650589106911,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -214126.80521207751,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.92547675327277135,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -223222.93762258449,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.94492949498379941,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -229895.57465282839,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.95894853804117852,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -240003.81612398339,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.979803686712769,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -244064.29661276529,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -0.98805727893228,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -253884.3362742863,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.0077387285884889,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -259570.1238903646,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.018960497547112,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -274165.328172819,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.047215981873499,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -283336.09120653989,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.0645864759737269,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -288225.92719689809,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.0737335371439194,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -297350.78483045712,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.09059760650839,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -301055.71221588022,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.097370880269529,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -316221.39474900393,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.1246713204292249,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -317060.74671177007,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.1261629486211491,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -334528.25056612171,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.156768344252421,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -347548.48344749858,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.179064855633478,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -372964.2843963927,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.221416037877991,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -378028.03081502032,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.229679683193994,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -388815.66217016062,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.247101699413742,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, -394431.31787162268,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     0.0, 0.0,
                                     1.0, -1.256075344669455};
  static const double b_b_df[520] = {
      0.0, 0.008320756923076926,    0.0, 0.0065853999999999956,
      0.0, -0.0045507713846153841,  0.0, 2.3593846153845192E-5,
      0.0, 2.7445538461513241E-5,   0.0, -0.00249863076923077,
      0.0, 1.609753846154618E-5,    0.0, -0.0022254400000000008,
      0.0, -0.002463941538461537,   0.0, 0.00223066153846153,
      0.0, -2.8643076923081969E-5,  0.0, 8.7846153846164549E-6,
      0.0, 1.9177230769230859E-5,   0.0, 0.003132307692307692,
      0.0, 0.00063538461538461828,  0.0, -3.5815384615377248E-5,
      0.0, 2.066923076923129E-6,    0.0, -1.4461538461705661E-7,
      0.0, -9.523076923055062E-6,   0.0, 5.5323076923078142E-5,
      0.0, -1.191384615384621E-5,   0.0, -3.2095384615384731E-5,
      0.0, -1.5276923076928691E-6,  0.0, -3.313846153849669E-7,
      0.0, -0.0002440030769230776,  0.0, 3.4061538461520358E-6,
      0.0, 3.0769230769294318E-7,   0.0, 5.15999999999943E-6,
      0.0, 4.5215384615379618E-5,   0.0, -8.59200000000264E-7,
      0.0, 6.1806153846194636E-6,   0.0, 9.969230769234908E-8,
      0.0, -2.6215384615387891E-5,  0.0, -5.0276923076923239E-5,
      0.0, 1.3415384615457819E-6,   0.0, 0.00027900000000000082,
      0.0, -6.5280000000000527E-5,  0.0, 0.0004809135384615377,
      0.0, -6.4572307692307713E-5,  0.0, 1.0578461538461589E-5,
      0.0, 3.8012000000001492E-5,   0.0, 5.8218461538461282E-5,
      0.0, -2.194153846153877E-5,   0.0, -0.00079818153846153721,
      0.0, 0.00013226769230769271,  0.0, 3.2464615384613912E-5,
      0.0, 8.8439384615396387E-5,   0.0, 0.0087015753846153947,
      0.0, 0.0001038030769230861,   0.0, -0.00037063692307692488,
      0.0, -0.0069612153846153836,  0.0, -0.00084236923076923,
      0.0, -0.02028408936820085,    0.0, -0.01917573822362954,
      0.0, -0.050332117293214122,   0.0, 0.00017401236588194131,
      0.0, 7.5046009170591643E-6,   0.0, -0.0331079744840978,
      0.0, -3.5741380815567552E-5,  0.0, -0.047396984974355107,
      0.0, 0.07450339366742105,     0.0, 0.001964805512433017,
      0.0, -0.00019968240384938941, 0.0, 5.6516417671537786E-6,
      0.0, -0.00196204276914072,    0.0, -0.0063280641260071487,
      0.0, -0.0013335468115891491,  0.0, 0.00014313218770316169,
      0.0, -0.00023459760633672989, 0.0, -9.6483638659862521E-5,
      0.0, 0.0016858162049253791,   0.0, -0.01697703398445943,
      0.0, 0.0002157549203026301,   0.0, 0.0077435122981707972,
      0.0, -0.00017203518714793611, 0.0, 7.7685000194821223E-5,
      0.0, 0.01470508166875594,     0.0, 9.0665602784118777E-7,
      0.0, 0.00020593681053143761,  0.0, 0.0078081469720444052,
      0.0, 4.29262961931611E-5,     0.0, -3.6730613043539878E-5,
      0.0, -5.0244673051062043E-5,  0.0, 0.00048017905966448549,
      0.0, -9.4008861002419316E-5,  0.0, 0.00257742824112801,
      0.0, 8.6306138097192017E-6,   0.0, 0.004202317993055143,
      0.0, -0.001048493933533806,   0.0, -0.00177394200299101,
      0.0, 0.0011312292340101479,   0.0, -0.00020575356572559691,
      0.0, 0.00098064365273438261,  0.0, 0.001004444670946637,
      0.0, -0.00029764326832194073, 0.0, -0.01193821943767185,
      0.0, -0.0049886864834683478,  0.0, 0.00058980575887233346,
      0.0, -0.00021359913917956371, 0.0, -0.00065294045594938466,
      0.0, -0.00079220034843404286, 0.0, 0.0085644382159712467,
      0.0, -0.015748081391969641,   0.0, -0.00138099444723674,
      0.0, 0.0096540544864419688,   0.0, -0.01163202554143886,
      0.0, -0.0112080844724667,     0.0, 3.8991103418184389E-5,
      0.0, 0.00018744858245097379,  0.0, 0.020152548174203429,
      0.0, 9.906953137522622E-5,    0.0, 0.02051594005585481,
      0.0, -0.070543142469148973,   0.0, -0.044373987083714719,
      0.0, 0.00057701933035178815,  0.0, 2.7359288201526761E-5,
      0.0, 0.0070067278074248491,   0.0, -0.0021995904773451308,
      0.0, -0.00045426829755807992, 0.0, 1.7266105640486431E-5,
      0.0, 0.00010334697399411461,  0.0, -2.3651989944297551E-6,
      0.0, -0.0002408698479152249,  0.0, 0.0017120551601996349,
      0.0, -1.2687209902627771E-5,  0.0, 0.0015495234145154039,
      0.0, 8.7508133047740959E-6,   0.0, 9.8497412856638663E-5,
      0.0, 0.03946244961935412,     0.0, 0.00040842752430981963,
      0.0, -9.9073891653510661E-5,  0.0, -0.0046964377497579783,
      0.0, 0.000108729033624576,    0.0, 5.6014471013789877E-5,
      0.0, -9.2546369420510632E-6,  0.0, 0.000384300455837554,
      0.0, 0.00036850405269307421,  0.0, 0.00319850945996064,
      0.0, 0.00072718931194515584,  0.0, -0.016490930816761191,
      0.0, 0.0031574213879833959,   0.0, 0.0048372685357203184,
      0.0, 0.0039254228428389224,   0.0, 0.00016628967527601281,
      0.0, -0.000407242887271996,   0.0, -0.00022437019258169381,
      0.0, -0.00046825830990990171, 0.0, -0.020657074438624759,
      0.0, -0.0069020276691464568,  0.0, 0.00077598782626265206,
      0.0, 0.0001014908067770024,   0.0, -0.001735771988292981,
      0.0, -0.000296634453801802,   0.0, 0.0058872119588950587,
      0.0, -0.0014413788705655861,  0.0, -0.00177066463838367,
      0.0, -0.0040428003580101251,  0.0, 0.0074533822429511528,
      0.0, 0.00675336986255086,     0.0, -0.01214358152176909,
      0.0, -0.0184522418228579,     0.0, -0.0053156546824436861,
      0.0, -0.005784926297461539,   0.0, 0.01007161819628742,
      0.0, 0.0099811730068321558,   0.0, 0.016725323182585392,
      0.0, 0.058961561513053637,    0.0, 0.099212696332003261,
      0.0, -0.02273034167112653,    0.0, 0.0071072743908696511,
      0.0, -0.024456802788191359,   0.0, -0.0225282404897517,
      0.0, 0.060418491782594348,    0.0, 0.03091285972196119,
      0.0, -0.0020977979095101128,  0.0, 0.06998252935527037,
      0.0, -0.00062013179746458048, 0.0, 0.01957157968799891,
      0.0, 0.032313440511189263,    0.0, -0.0071153149194514509,
      0.0, 0.089621056139394709,    0.0, 0.0073898092281106222,
      0.0, -0.016483521469336911,   0.0, -0.048854396482386361,
      0.0, 0.0050727113573692329,   0.0, 0.027054124644752951,
      0.0, -0.0078139623198636311,  0.0, -0.0363151838560942,
      0.0, 0.01355254005566817,     0.0, -0.043992907011276658,
      0.0, 0.035938381876238032,    0.0, -0.15004597200136369,
      0.0, -0.01279734311026298,    0.0, 0.0057557493447683268,
      0.0, 0.0198531541439508,      0.0, 0.0022292579060057892,
      0.0, -0.0013548360989590251,  0.0, 0.00093487139263362558,
      0.0, 0.0084864464580716673,   0.0, -0.091530654463505251,
      0.0, -0.065284615397894624,   0.0, -0.0081798580013035145,
      0.0, 0.0263781227908255,      0.0, 0.00048200608246749322,
      0.0, 0.03940911522087126,     0.0, -0.17136697661704661,
      0.0, 0.02564680202616346,     0.0, -0.035870834732484209,
      0.0, 0.0039324732961645709,   0.0, -0.007593121890897103,
      0.0, -0.0075416614088555586,  0.0, -0.012050109567904191,
      0.0, -0.018209846047884119,   0.0, 0.0056567649115213583,
      0.0, -0.0057411447961357581,  0.0, -0.010198305432373879,
      0.0, -0.0099500589090496978,  0.0, -0.015912022138171521,
      0.0, 0.059086734067436031,    0.0, 0.0992841302200189,
      0.0, 0.023166051028904549,    0.0, 0.0022107087942586289,
      0.0, -0.02455766460841945,    0.0, -0.021401089625040681,
      0.0, 0.0589128374195349,      0.0, 0.030095076570868708,
      0.0, 0.01097410851754513,     0.0, -0.070591404052476714,
      0.0, 0.0022084232892898648,   0.0, -0.019187685233566971,
      0.0, 0.03111064053180964,     0.0, -0.0079105713432141879,
      0.0, -0.09025196572903621,    0.0, 0.0055835836709738958,
      0.0, -0.014852297057966059,   0.0, 0.048945935752260028,
      0.0, 0.0048189169315320706,   0.0, 0.025597760264376671,
      0.0, -0.0076758314089119912,  0.0, 0.035289635636920808,
      0.0, 0.010525182605796379,    0.0, 0.041272275986769927,
      0.0, 0.026174867780662081,    0.0, 0.13343504659095989,
      0.0, -0.073044822987175323,   0.0, -0.0059794632994338674,
      0.0, -0.0220711779889558,     0.0, -0.0043628552308314743,
      0.0, 0.0199471501891688,      0.0, 0.02347865569282874,
      0.0, 0.01489152586798825,     0.0, 0.091990534816266345,
      0.0, 0.06344316825951378,     0.0, -0.016873668952046759,
      0.0, 0.02219990512445736,     0.0, -0.00076477779292602422,
      0.0, -0.00020938302908622,    0.0, 0.166599021410397,
      0.0, -0.0144830576027064,     0.0, -0.054790779983943542};
  static const double c_n[27] = {0.0, 0.0, 35.0, 0.0, 0.0, 0.0, 0.0, 0.0, -20.5,
                                 0.0, 0.0, 0.0,  0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                 0.0, 0.0, -1.4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
  static const double r_n1_n[27] = {
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,  0.0, 0.0, 0.0, 0.0, -41.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1.4, 0.0, 0.0, 0.0, 0.0, 0.0,   0.0};
  static const double k_d[9] = {0.0,
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                0.0017453292519943296,
                                0.0,
                                101.03078247185243,
                                101.03078247185243};
  static const double g0[3] = {0.0, 0.0, -9.72};
  static const double hs_rw_max[3] = {0.0, 0.0, 56.548667764616276};
  static const int b_i_n[81] = {
      0, 0, 544800,  0, 0, 1,  3778, 14, 34, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0,       0, 0, 0,  0,    0,  0,  0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 5448000, 0, 0, 10, 3787, 21, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0,       0, 0, 0,  0,    0,  0,  0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 5448000, 0, 0, 10, 2655, 30, 25};
  static const int iv[9] = {0, 0, 100000, 0, 0, 10, 1850, 60, 200};
  static const int m_n[9] = {0, 0, 100000, 0, 0, 10, 1850, 60, 200};
  static const signed char p_n[54] = {0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0,
                                      0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
                                      1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1,
                                      0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0};
  static const signed char z_n[27] = {0, 0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1,
                                      0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 0};
  static const signed char a[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
  double m_w_n[324];
  double sys_workspace_p_n[54];
  double sys_workspace_z_n[27];
  double i_n[9];
  double offterm[9];
  double sys_workspace_b_d[9];
  double b_tau[5];
  double c_tau[5];
  double d_tau[5];
  double tau[5];
  double tau_app_flex_idx_0;
  double tau_app_flex_idx_1;
  double tau_app_flex_idx_2;
  int i;
  int i1;
  int k;
  int m_w_n_tmp;
  if (sb_flag != 0) {
    /* %% This file initializes are parameters for simulating BIT (9 DOF) */
    /* each column is vector (F4 is -61m from F3) */
    /* each column is vector */
    /*  was 350 */
    /*  m_n = [0.0,0.0,100000.0,0.0,0.0,1.0,350.0,73.0,150.0]; */
    /* each column is vector (COM of B3 (flight train) is 30.5m along z */
    /* each row is row wise matric % Updated gondola on april 13 according to */
    /* michaels model */
    /*  i_n = [ [  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,   0.0], */
    /*          [  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,   0.0], */
    /*          [5448000.0,  0.0,  0.0,  0.0, 5448000.0,  0.0,  0.0,  0.0,
     * 5448000.0], */
    /*          [  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,   0.0], */
    /*          [  1.0,  0.0,  0.0,  0.0,  1.0,  0.0,  0.0,  0.0,   1.0], */
    /*          [  246*yaw_sc,    0,    0,    0,  455*yaw_sc,    0,    0,    0,
     * 408*yaw_sc], */
    /*          [ 151,  0.0,  0.0,  0.0, 405,  0.0,  0.0,  0.0,  339]/1.1, */
    /*          [   213,  0.0,  0.0,  0.0, 134.0,  0.0, 0, 0, 244]/1.1]; */
    /*  i_n = [ [  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,   0.0], */
    /*          [  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,   0.0], */
    /*          [5448000.0,  0.0,  0.0,  0.0, 5448000.0,  0.0,  0.0,  0.0,
     * 5448000.0], */
    /*          [  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,   0.0], */
    /*          [  10.0,  0.0,  0.0,  0.0,  100.0,  0.0,  0.0,  0.0,   100.0],
     */
    /*          [  3778,    0,    0,    0,  3787,    0,    0,    0,   2655], */
    /*          [ 14,  0.0,  0.0,  0.0, 21,  0.0,  0.0,  0.0,  30], */
    /*          [   34,  0.0,  0.0,  0.0, 40,  0.0, 0, 0, 25]]; */
    offterm[0] = 0.0;
    offterm[4] = 0.0;
    offterm[8] = 0.0;
    for (k = 0; k < 9; k++) {
      tau_app_flex_idx_0 = c_n[3 * k];
      tau_app_flex_idx_1 = c_n[3 * k + 1];
      tau_app_flex_idx_2 = c_n[3 * k + 2];
      offterm[3] = -tau_app_flex_idx_2;
      offterm[6] = tau_app_flex_idx_1;
      offterm[1] = tau_app_flex_idx_2;
      offterm[7] = -tau_app_flex_idx_0;
      offterm[2] = -tau_app_flex_idx_1;
      offterm[5] = tau_app_flex_idx_0;
      for (i = 0; i < 9; i++) {
        i_n[i] = b_i_n[k + 9 * i];
      }
      i = iv[k];
      for (i1 = 0; i1 < 3; i1++) {
        int b_m_w_n_tmp;
        int c_m_w_n_tmp;
        m_w_n_tmp = 6 * i1 + 36 * k;
        m_w_n[m_w_n_tmp] = a[3 * i1] * i;
        tau_app_flex_idx_0 = offterm[3 * i1];
        b_m_w_n_tmp = 6 * (i1 + 3) + 36 * k;
        m_w_n[b_m_w_n_tmp] = -tau_app_flex_idx_0;
        m_w_n[m_w_n_tmp + 3] = tau_app_flex_idx_0;
        m_w_n[b_m_w_n_tmp + 3] = i_n[3 * i1];
        c_m_w_n_tmp = 3 * i1 + 1;
        m_w_n[m_w_n_tmp + 1] = a[c_m_w_n_tmp] * i;
        tau_app_flex_idx_0 = offterm[c_m_w_n_tmp];
        m_w_n[b_m_w_n_tmp + 1] = -tau_app_flex_idx_0;
        m_w_n[m_w_n_tmp + 4] = tau_app_flex_idx_0;
        m_w_n[b_m_w_n_tmp + 4] = i_n[c_m_w_n_tmp];
        c_m_w_n_tmp = 3 * i1 + 2;
        m_w_n[m_w_n_tmp + 2] = a[c_m_w_n_tmp] * i;
        tau_app_flex_idx_0 = offterm[c_m_w_n_tmp];
        m_w_n[b_m_w_n_tmp + 2] = -tau_app_flex_idx_0;
        m_w_n[m_w_n_tmp + 5] = tau_app_flex_idx_0;
        m_w_n[b_m_w_n_tmp + 5] = i_n[c_m_w_n_tmp];
      }
    }
    /*  bear_k_cst = 2.0*0.9486*(0.0254*4.44822162)*180.0/pi; */
    /* SB spring constant */
    /*  theta_0 =
     * [0.,0.4*pi/180.0,0.4*pi/180.0,0.1*pi/180.0,0.1*pi/180.0,0.1*pi/180.0,0.,0.1,-40*pi/180]';
     */
    /* setting IC from past sim */
    /*  y0 = [0.017552353814854, -0.002156992032555, -0.002273627285241, ... */
    /*      -0.004091940730352,  -0.002796089196615,   0.019674817779806,... */
    /*      -0.017606183923045,                   0,                   0, ... */
    /*       0.207860712172010,  -0.003878840466313,  -0.004340266988222, ... */
    /*      -0.001098037684871,  -0.001085183886166,  -0.001924742862772, ... */
    /*       2.937417436471931,                   0,                   0, ... */
    /*                       0,                   0, 28.274274172758336]'; */
    for (i = 0; i < 27; i++) {
      sys_workspace_z_n[i] = z_n[i];
    }
    for (i = 0; i < 54; i++) {
      sys_workspace_p_n[i] = p_n[i];
    }
    for (k = 0; k < 9; k++) {
      i_n[k] = m_n[k];
      offterm[k] = k_d[k];
      sys_workspace_b_d[k] = 0.0;
    }
  } else {
    /* %% This file initializes are parameters for simulating BIT (9 DOF) */
    /* each column is vector (F4 is -61m from F3) */
    /* each column is vector */
    /*  was 350 */
    /*  m_n = [0.0,0.0,100000.0,0.0,0.0,1.0,350.0,73.0,150.0]; */
    /* each column is vector (COM of B3 (flight train) is 30.5m along z */
    /* each row is row wise matric % Updated gondola on april 13 according to */
    /* michaels model */
    /*  i_n = [ [  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,   0.0], */
    /*          [  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,   0.0], */
    /*          [5448000.0,  0.0,  0.0,  0.0, 5448000.0,  0.0,  0.0,  0.0,
     * 5448000.0], */
    /*          [  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,   0.0], */
    /*          [  1.0,  0.0,  0.0,  0.0,  1.0,  0.0,  0.0,  0.0,   1.0], */
    /*          [  246*yaw_sc,    0,    0,    0,  455*yaw_sc,    0,    0,    0,
     * 408*yaw_sc], */
    /*          [ 151,  0.0,  0.0,  0.0, 405,  0.0,  0.0,  0.0,  339]/1.1, */
    /*          [   213,  0.0,  0.0,  0.0, 134.0,  0.0, 0, 0, 244]/1.1]; */
    /*  i_n = [ [  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,   0.0], */
    /*          [  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,   0.0], */
    /*          [5448000.0,  0.0,  0.0,  0.0, 5448000.0,  0.0,  0.0,  0.0,
     * 5448000.0], */
    /*          [  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,   0.0], */
    /*          [  10.0,  0.0,  0.0,  0.0,  100.0,  0.0,  0.0,  0.0,   100.0],
     */
    /*          [  3778,    0,    0,    0,  3787,    0,    0,    0,   2655], */
    /*          [ 14,  0.0,  0.0,  0.0, 21,  0.0,  0.0,  0.0,  30], */
    /*          [   34,  0.0,  0.0,  0.0, 40,  0.0, 0, 0, 25]]; */
    offterm[0] = 0.0;
    offterm[4] = 0.0;
    offterm[8] = 0.0;
    for (k = 0; k < 9; k++) {
      tau_app_flex_idx_0 = c_n[3 * k];
      tau_app_flex_idx_1 = c_n[3 * k + 1];
      tau_app_flex_idx_2 = c_n[3 * k + 2];
      offterm[3] = -tau_app_flex_idx_2;
      offterm[6] = tau_app_flex_idx_1;
      offterm[1] = tau_app_flex_idx_2;
      offterm[7] = -tau_app_flex_idx_0;
      offterm[2] = -tau_app_flex_idx_1;
      offterm[5] = tau_app_flex_idx_0;
      for (i = 0; i < 9; i++) {
        i_n[i] = b_i_n[k + 9 * i];
      }
      i = iv[k];
      for (i1 = 0; i1 < 3; i1++) {
        int b_m_w_n_tmp;
        int c_m_w_n_tmp;
        m_w_n_tmp = 6 * i1 + 36 * k;
        m_w_n[m_w_n_tmp] = a[3 * i1] * i;
        tau_app_flex_idx_0 = offterm[3 * i1];
        b_m_w_n_tmp = 6 * (i1 + 3) + 36 * k;
        m_w_n[b_m_w_n_tmp] = -tau_app_flex_idx_0;
        m_w_n[m_w_n_tmp + 3] = tau_app_flex_idx_0;
        m_w_n[b_m_w_n_tmp + 3] = i_n[3 * i1];
        c_m_w_n_tmp = 3 * i1 + 1;
        m_w_n[m_w_n_tmp + 1] = a[c_m_w_n_tmp] * i;
        tau_app_flex_idx_0 = offterm[c_m_w_n_tmp];
        m_w_n[b_m_w_n_tmp + 1] = -tau_app_flex_idx_0;
        m_w_n[m_w_n_tmp + 4] = tau_app_flex_idx_0;
        m_w_n[b_m_w_n_tmp + 4] = i_n[c_m_w_n_tmp];
        c_m_w_n_tmp = 3 * i1 + 2;
        m_w_n[m_w_n_tmp + 2] = a[c_m_w_n_tmp] * i;
        tau_app_flex_idx_0 = offterm[c_m_w_n_tmp];
        m_w_n[b_m_w_n_tmp + 2] = -tau_app_flex_idx_0;
        m_w_n[m_w_n_tmp + 5] = tau_app_flex_idx_0;
        m_w_n[b_m_w_n_tmp + 5] = i_n[c_m_w_n_tmp];
      }
    }
    /*  bear_k_cst = 2.0*0.9486*(0.0254*4.44822162)*180.0/pi; */
    /* SB spring constant */
    /*  theta_0 =
     * [0.,0.4*pi/180.0,0.4*pi/180.0,0.1*pi/180.0,0.1*pi/180.0,0.1*pi/180.0,0.,0.1,-40*pi/180]';
     */
    /* setting IC from past sim */
    /*  y0 = [0.017552353814854, -0.002156992032555, -0.002273627285241, ... */
    /*      -0.004091940730352,  -0.002796089196615,   0.019674817779806,... */
    /*      -0.017606183923045,                   0,                   0, ... */
    /*       0.207860712172010,  -0.003878840466313,  -0.004340266988222, ... */
    /*      -0.001098037684871,  -0.001085183886166,  -0.001924742862772, ... */
    /*       2.937417436471931,                   0,                   0, ... */
    /*                       0,                   0, 28.274274172758336]'; */
    for (i = 0; i < 27; i++) {
      sys_workspace_z_n[i] = z_n[i];
    }
    for (i = 0; i < 54; i++) {
      sys_workspace_p_n[i] = p_n[i];
    }
    for (k = 0; k < 9; k++) {
      i_n[k] = m_n[k];
      offterm[k] = k_d[k];
      sys_workspace_b_d[k] = 0.0;
    }
  }
  if (flexure_flag == 0) {
    offterm[7] = 0.0;
    offterm[8] = 0.0;
  }
  /*     %% Setup Simulation */
  /*  initial conditions, state is dtheta; theta */
  memcpy(&y_true[0], &x0[0], 21U * sizeof(double));
  memcpy(&y_flex[0], &x_flex0[0], 104U * sizeof(double));
  /*  Sim Parameters */
  /*  y_all1 = zeros(18, tf/(dt)); */
  tau_applied[6] += tau_flex[0];
  tau_applied[7] = (tau_flex[1] + tau_applied[7]) + tau_flex[2];
  tau_applied[8] = (tau_flex[3] + tau_applied[8]) + tau_flex[4];
  /*  sim */
  i = num_steps;
  for (m_w_n_tmp = 0; m_w_n_tmp < i; m_w_n_tmp++) {
    double b_df[104];
    double kf1[104];
    double kf2[104];
    double kf3[104];
    double k1[24];
    double k2[24];
    double k3[24];
    double varargout_1[24];
    double b_y_true[21];
    double b_tau_tmp;
    double c_tau_tmp;
    double d_tau_tmp;
    double tau_tmp;
    boolean_T th_over[9];
    boolean_T th_under[9];
    /*         %% Propagate the system */
    /* RK4 solver */
    tau_app_flex_idx_0 = (w_piv - y_true[5]) / dt;
    bit_one_step_anonFcn1(
        c_n, sys_workspace_z_n, i_n, r_n1_n, m_w_n, sys_workspace_p_n, offterm,
        sys_workspace_b_d, g0, unlock, hs_rw_max, w_piv, piv_flag, tau_max_piv,
        thet_pit_nom, y_true, tau_applied, tau_app_flex_idx_0, k1);
    for (i1 = 0; i1 < 24; i1++) {
      k1[i1] *= dt;
    }
    for (i1 = 0; i1 < 21; i1++) {
      b_y_true[i1] = y_true[i1] + k1[i1] / 2.0;
    }
    bit_one_step_anonFcn1(
        c_n, sys_workspace_z_n, i_n, r_n1_n, m_w_n, sys_workspace_p_n, offterm,
        sys_workspace_b_d, g0, unlock, hs_rw_max, w_piv, piv_flag, tau_max_piv,
        thet_pit_nom, b_y_true, tau_applied, tau_app_flex_idx_0, k2);
    for (i1 = 0; i1 < 24; i1++) {
      k2[i1] *= dt;
    }
    for (i1 = 0; i1 < 21; i1++) {
      b_y_true[i1] = y_true[i1] + k2[i1] / 2.0;
    }
    bit_one_step_anonFcn1(
        c_n, sys_workspace_z_n, i_n, r_n1_n, m_w_n, sys_workspace_p_n, offterm,
        sys_workspace_b_d, g0, unlock, hs_rw_max, w_piv, piv_flag, tau_max_piv,
        thet_pit_nom, b_y_true, tau_applied, tau_app_flex_idx_0, k3);
    for (i1 = 0; i1 < 24; i1++) {
      k3[i1] *= dt;
    }
    for (i1 = 0; i1 < 21; i1++) {
      b_y_true[i1] = y_true[i1] + k3[i1];
    }
    bit_one_step_anonFcn1(
        c_n, sys_workspace_z_n, i_n, r_n1_n, m_w_n, sys_workspace_p_n, offterm,
        sys_workspace_b_d, g0, unlock, hs_rw_max, w_piv, piv_flag, tau_max_piv,
        thet_pit_nom, b_y_true, tau_applied, tau_app_flex_idx_0, varargout_1);
    for (i1 = 0; i1 < 24; i1++) {
      k1[i1] =
          (((k1[i1] + 2.0 * k2[i1]) + 2.0 * k3[i1]) + varargout_1[i1] * dt) /
          6.0;
    }
    for (i1 = 0; i1 < 21; i1++) {
      y_true[i1] += k1[i1];
    }
    for (k = 0; k < 9; k++) {
      tau_app_flex_idx_0 = y_true[k + 9];
      th_over[k] = (tau_app_flex_idx_0 > 3.1415926535897931);
      th_under[k] = (tau_app_flex_idx_0 < -3.1415926535897931);
    }
    for (i1 = 0; i1 < 5; i1++) {
      y_true[i1 + 9] =
          (y_true[i1 + 9] - 6.2831853071795862 * (double)th_over[i1]) +
          6.2831853071795862 * (double)th_under[i1];
    }
    y_true[15] = (y_true[15] - 6.2831853071795862 * (double)th_over[6]) +
                 6.2831853071795862 * (double)th_under[6];
    y_true[16] = (y_true[16] - 6.2831853071795862 * (double)th_over[7]) +
                 6.2831853071795862 * (double)th_under[7];
    y_true[17] = (y_true[17] - 6.2831853071795862 * (double)th_over[8]) +
                 6.2831853071795862 * (double)th_under[8];
    /*          fprintf('current state:  %0.15f \n  %0.15f \n %0.15f \n %0.15f
     * \n %0.15f \n %0.15f \n %0.15f \n %0.15f \n %0.15f \n %0.15f \n %0.15f \n
     * %0.15f \n %0.15f \n %0.15f \n %0.15f \n %0.15f \n %0.15f \n %0.15f \n
     * %0.15f \n %0.15f \n %0.15f \n \n', ... */
    /*              y_true(1), y_true(2), y_true(3), y_true(4), y_true(5),
     * y_true(6),... */
    /*               y_true(7), y_true(8), y_true(9), y_true(10), y_true(11),
     * y_true(12),... */
    /*                y_true(13), y_true(14), y_true(15), y_true(16),
     * y_true(17), y_true(18),... */
    /*                 y_true(19), y_true(20), y_true(21));       */
    /*         %% Propogate flexible system */
    /* UNTITLED Summary of this function goes here */
    /*    Detailed explanation goes here */
    tau_app_flex_idx_0 = k1[22] / dt - (tau_flex[1] + tau_flex[2]);
    tau_app_flex_idx_1 = k1[23] / dt - (tau_flex[3] + tau_flex[4]);
    /*   */
    tau_tmp = -tau_flex[0] + (k1[21] / dt - tau_flex[0]);
    tau[0] = tau_tmp;
    b_tau_tmp = tau_flex[1] + tau_app_flex_idx_0 / 2.0;
    tau[1] = b_tau_tmp;
    c_tau_tmp = tau_flex[2] + tau_app_flex_idx_0 / 2.0;
    tau[2] = c_tau_tmp;
    d_tau_tmp = tau_flex[3] + tau_app_flex_idx_1 / 2.0;
    tau[3] = d_tau_tmp;
    tau_app_flex_idx_1 = tau_flex[4] + tau_app_flex_idx_1 / 2.0;
    tau[4] = tau_app_flex_idx_1;
    /* UNTITLED Summary of this function goes here */
    /*    Detailed explanation goes here */
    /*   */
    b_tau[0] = tau_tmp;
    b_tau[1] = b_tau_tmp;
    b_tau[2] = c_tau_tmp;
    b_tau[3] = d_tau_tmp;
    b_tau[4] = tau_app_flex_idx_1;
    for (i1 = 0; i1 < 104; i1++) {
      tau_app_flex_idx_0 = 0.0;
      for (k = 0; k < 104; k++) {
        tau_app_flex_idx_0 += a_df[i1 + 104 * k] * y_flex[k];
      }
      tau_app_flex_idx_2 = 0.0;
      for (k = 0; k < 5; k++) {
        tau_app_flex_idx_2 += b_b_df[i1 + 104 * k] * tau[k];
      }
      tau_app_flex_idx_0 = (tau_app_flex_idx_0 + tau_app_flex_idx_2) * dt;
      kf1[i1] = tau_app_flex_idx_0;
      b_df[i1] = y_flex[i1] + tau_app_flex_idx_0 / 2.0;
    }
    for (i1 = 0; i1 < 104; i1++) {
      tau_app_flex_idx_0 = 0.0;
      for (k = 0; k < 104; k++) {
        tau_app_flex_idx_0 += a_df[i1 + 104 * k] * b_df[k];
      }
      kf2[i1] = tau_app_flex_idx_0;
    }
    /* UNTITLED Summary of this function goes here */
    /*    Detailed explanation goes here */
    /*   */
    c_tau[0] = tau_tmp;
    c_tau[1] = b_tau_tmp;
    c_tau[2] = c_tau_tmp;
    c_tau[3] = d_tau_tmp;
    c_tau[4] = tau_app_flex_idx_1;
    for (i1 = 0; i1 < 104; i1++) {
      tau_app_flex_idx_0 = 0.0;
      for (k = 0; k < 5; k++) {
        tau_app_flex_idx_0 += b_b_df[i1 + 104 * k] * b_tau[k];
      }
      tau_app_flex_idx_0 = (kf2[i1] + tau_app_flex_idx_0) * dt;
      kf2[i1] = tau_app_flex_idx_0;
      b_df[i1] = y_flex[i1] + tau_app_flex_idx_0 / 2.0;
    }
    for (i1 = 0; i1 < 104; i1++) {
      tau_app_flex_idx_0 = 0.0;
      for (k = 0; k < 104; k++) {
        tau_app_flex_idx_0 += a_df[i1 + 104 * k] * b_df[k];
      }
      kf3[i1] = tau_app_flex_idx_0;
    }
    /* UNTITLED Summary of this function goes here */
    /*    Detailed explanation goes here */
    /*   */
    d_tau[0] = tau_tmp;
    d_tau[1] = b_tau_tmp;
    d_tau[2] = c_tau_tmp;
    d_tau[3] = d_tau_tmp;
    d_tau[4] = tau_app_flex_idx_1;
    for (i1 = 0; i1 < 104; i1++) {
      tau_app_flex_idx_0 = 0.0;
      for (k = 0; k < 5; k++) {
        tau_app_flex_idx_0 += b_b_df[i1 + 104 * k] * c_tau[k];
      }
      tau_app_flex_idx_0 = (kf3[i1] + tau_app_flex_idx_0) * dt;
      kf3[i1] = tau_app_flex_idx_0;
      b_df[i1] = y_flex[i1] + tau_app_flex_idx_0;
    }
    for (i1 = 0; i1 < 104; i1++) {
      tau_app_flex_idx_0 = 0.0;
      for (k = 0; k < 104; k++) {
        tau_app_flex_idx_0 += a_df[i1 + 104 * k] * b_df[k];
      }
      tau_app_flex_idx_2 = 0.0;
      for (k = 0; k < 5; k++) {
        tau_app_flex_idx_2 += b_b_df[i1 + 104 * k] * d_tau[k];
      }
      y_flex[i1] += (((kf1[i1] + 2.0 * kf2[i1]) + 2.0 * kf3[i1]) +
                     (tau_app_flex_idx_0 + tau_app_flex_idx_2) * dt) /
                    6.0;
    }
  }
}

/*
 * UNTITLED2 Summary of this function goes here
 *    Detailed explanation goes here
 *
 * Arguments    : const double x[18]
 *                const double z_n[27]
 *                double omega[3]
 * Return Type  : void
 */
void compute_angular_velocity_C(const double x[18], const double z_n[27],
                                double omega[3])
{
  double b_Cn[27];
  double s9[27];
  double d;
  int b_i;
  int i;
  int s9_tmp;
  memset(&s9[0], 0, 27U * sizeof(double));
  for (i = 0; i < 9; i++) {
    double Cn[9];
    axis2rot(&z_n[3 * i], x[i + 9], Cn);
    s9[3 * i] = z_n[3 * i];
    s9_tmp = 3 * i + 1;
    s9[s9_tmp] = z_n[s9_tmp];
    s9_tmp = 3 * i + 2;
    s9[s9_tmp] = z_n[s9_tmp];
    for (s9_tmp = 0; s9_tmp < 3; s9_tmp++) {
      double d1;
      double d2;
      d = Cn[s9_tmp];
      d1 = Cn[s9_tmp + 3];
      d2 = Cn[s9_tmp + 6];
      for (b_i = 0; b_i < 9; b_i++) {
        b_Cn[s9_tmp + 3 * b_i] =
            (d * s9[3 * b_i] + d1 * s9[3 * b_i + 1]) + d2 * s9[3 * b_i + 2];
      }
    }
    memcpy(&s9[0], &b_Cn[0], 27U * sizeof(double));
  }
  for (s9_tmp = 0; s9_tmp < 3; s9_tmp++) {
    d = 0.0;
    for (b_i = 0; b_i < 9; b_i++) {
      d += s9[s9_tmp + 3 * b_i] * x[b_i];
    }
    omega[s9_tmp] = d;
  }
}

/*
 * UNTITLED2 Summary of this function goes here
 *    Detailed explanation goes here
 *
 * Arguments    : const double x[18]
 *                const double z_n[27]
 *                double omega[3]
 * Return Type  : void
 */
void compute_angular_velocity_roll_C(const double x[18], const double z_n[27],
                                     double omega[3])
{
  double b_Cn[24];
  double s8[24];
  double d;
  int b_i;
  int i;
  int s8_tmp;
  memset(&s8[0], 0, 24U * sizeof(double));
  for (i = 0; i < 8; i++) {
    double Cn[9];
    axis2rot(&z_n[3 * i], x[i + 9], Cn);
    s8[3 * i] = z_n[3 * i];
    s8_tmp = 3 * i + 1;
    s8[s8_tmp] = z_n[s8_tmp];
    s8_tmp = 3 * i + 2;
    s8[s8_tmp] = z_n[s8_tmp];
    for (s8_tmp = 0; s8_tmp < 3; s8_tmp++) {
      double d1;
      double d2;
      d = Cn[s8_tmp];
      d1 = Cn[s8_tmp + 3];
      d2 = Cn[s8_tmp + 6];
      for (b_i = 0; b_i < 8; b_i++) {
        b_Cn[s8_tmp + 3 * b_i] =
            (d * s8[3 * b_i] + d1 * s8[3 * b_i + 1]) + d2 * s8[3 * b_i + 2];
      }
    }
    memcpy(&s8[0], &b_Cn[0], 24U * sizeof(double));
  }
  for (s8_tmp = 0; s8_tmp < 3; s8_tmp++) {
    d = 0.0;
    for (b_i = 0; b_i < 8; b_i++) {
      d += s8[s8_tmp + 3 * b_i] * x[b_i];
    }
    omega[s8_tmp] = d;
  }
}

/*
 * UNTITLED2 Summary of this function goes here
 *    Detailed explanation goes here
 *
 * Arguments    : const double x[18]
 *                const double z_n[27]
 *                double omega[3]
 * Return Type  : void
 */
void compute_angular_velocity_yaw_C(const double x[18], const double z_n[27],
                                    double omega[3])
{
  double b_Cn[21];
  double s7[21];
  double d;
  int b_i;
  int i;
  int s7_tmp;
  memset(&s7[0], 0, 21U * sizeof(double));
  for (i = 0; i < 7; i++) {
    double Cn[9];
    axis2rot(&z_n[3 * i], x[i + 9], Cn);
    s7[3 * i] = z_n[3 * i];
    s7_tmp = 3 * i + 1;
    s7[s7_tmp] = z_n[s7_tmp];
    s7_tmp = 3 * i + 2;
    s7[s7_tmp] = z_n[s7_tmp];
    for (s7_tmp = 0; s7_tmp < 3; s7_tmp++) {
      double d1;
      double d2;
      d = Cn[s7_tmp];
      d1 = Cn[s7_tmp + 3];
      d2 = Cn[s7_tmp + 6];
      for (b_i = 0; b_i < 7; b_i++) {
        b_Cn[s7_tmp + 3 * b_i] =
            (d * s7[3 * b_i] + d1 * s7[3 * b_i + 1]) + d2 * s7[3 * b_i + 2];
      }
    }
    memcpy(&s7[0], &b_Cn[0], 21U * sizeof(double));
  }
  for (s7_tmp = 0; s7_tmp < 3; s7_tmp++) {
    d = 0.0;
    for (b_i = 0; b_i < 7; b_i++) {
      d += s7[s7_tmp + 3 * b_i] * x[b_i];
    }
    omega[s7_tmp] = d;
  }
}

/*
 * UNTITLED3 Summary of this function goes here
 *    Detailed explanation goes here
 *
 * Arguments    : const double z_n[27]
 *                const double theta[9]
 *                double C[9]
 * Return Type  : void
 */
void compute_rotation_mat_C(const double z_n[27], const double theta[9],
                            double C[9])
{
  double a[9];
  double b_a[9];
  int b_i;
  int i;
  int i1;
  memset(&C[0], 0, 9U * sizeof(double));
  C[0] = 1.0;
  C[4] = 1.0;
  C[8] = 1.0;
  for (i = 0; i < 9; i++) {
    axis2rot(&z_n[3 * i], theta[i], b_a);
    for (b_i = 0; b_i < 3; b_i++) {
      double d;
      double d1;
      double d2;
      d = b_a[b_i];
      d1 = b_a[b_i + 3];
      d2 = b_a[b_i + 6];
      for (i1 = 0; i1 < 3; i1++) {
        a[b_i + 3 * i1] =
            (d * C[3 * i1] + d1 * C[3 * i1 + 1]) + d2 * C[3 * i1 + 2];
      }
    }
    memcpy(&C[0], &a[0], 9U * sizeof(double));
  }
  for (b_i = 0; b_i < 3; b_i++) {
    b_a[3 * b_i] = C[b_i];
    b_a[3 * b_i + 1] = C[b_i + 3];
    b_a[3 * b_i + 2] = C[b_i + 6];
  }
  memcpy(&C[0], &b_a[0], 9U * sizeof(double));
}

/*
 * UNTITLED3 Summary of this function goes here
 *    Detailed explanation goes here
 *
 * Arguments    : const double z_n[27]
 *                const double theta[9]
 *                double C[9]
 * Return Type  : void
 */
void compute_rotation_mat_roll_C(const double z_n[27], const double theta[9],
                                 double C[9])
{
  double a[9];
  double b_a[9];
  int b_i;
  int i;
  int i1;
  memset(&C[0], 0, 9U * sizeof(double));
  C[0] = 1.0;
  C[4] = 1.0;
  C[8] = 1.0;
  for (i = 0; i < 8; i++) {
    axis2rot(&z_n[3 * i], theta[i], b_a);
    for (b_i = 0; b_i < 3; b_i++) {
      double d;
      double d1;
      double d2;
      d = b_a[b_i];
      d1 = b_a[b_i + 3];
      d2 = b_a[b_i + 6];
      for (i1 = 0; i1 < 3; i1++) {
        a[b_i + 3 * i1] =
            (d * C[3 * i1] + d1 * C[3 * i1 + 1]) + d2 * C[3 * i1 + 2];
      }
    }
    memcpy(&C[0], &a[0], 9U * sizeof(double));
  }
  for (b_i = 0; b_i < 3; b_i++) {
    b_a[3 * b_i] = C[b_i];
    b_a[3 * b_i + 1] = C[b_i + 3];
    b_a[3 * b_i + 2] = C[b_i + 6];
  }
  memcpy(&C[0], &b_a[0], 9U * sizeof(double));
}

/*
 * UNTITLED3 Summary of this function goes here
 *    Detailed explanation goes here
 *
 * Arguments    : const double z_n[27]
 *                const double theta[9]
 *                double C[9]
 * Return Type  : void
 */
void compute_rotation_mat_yaw_C(const double z_n[27], const double theta[9],
                                double C[9])
{
  double a[9];
  double b_a[9];
  int b_i;
  int i;
  int i1;
  memset(&C[0], 0, 9U * sizeof(double));
  C[0] = 1.0;
  C[4] = 1.0;
  C[8] = 1.0;
  for (i = 0; i < 7; i++) {
    axis2rot(&z_n[3 * i], theta[i], b_a);
    for (b_i = 0; b_i < 3; b_i++) {
      double d;
      double d1;
      double d2;
      d = b_a[b_i];
      d1 = b_a[b_i + 3];
      d2 = b_a[b_i + 6];
      for (i1 = 0; i1 < 3; i1++) {
        a[b_i + 3 * i1] =
            (d * C[3 * i1] + d1 * C[3 * i1 + 1]) + d2 * C[3 * i1 + 2];
      }
    }
    memcpy(&C[0], &a[0], 9U * sizeof(double));
  }
  for (b_i = 0; b_i < 3; b_i++) {
    b_a[3 * b_i] = C[b_i];
    b_a[3 * b_i + 1] = C[b_i + 3];
    b_a[3 * b_i + 2] = C[b_i + 6];
  }
  memcpy(&C[0], &b_a[0], 9U * sizeof(double));
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void libbitonestep_initialize(void)
{
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void libbitonestep_terminate(void)
{
}

/*
 * File trailer for libbitonestep.c
 *
 * [EOF]
 */
