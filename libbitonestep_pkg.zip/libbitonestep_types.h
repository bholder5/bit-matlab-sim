/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * libbitonestep_types.h
 *
 * Code generation for function 'bit_one_step'
 *
 */

#ifndef LIBBITONESTEP_TYPES_H
#define LIBBITONESTEP_TYPES_H

/* Include files */
#include "rtwtypes.h"

#endif
/* End of code generation (libbitonestep_types.h) */
